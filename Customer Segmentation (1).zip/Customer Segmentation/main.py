import preprocessing as ps
import clustering as cl
import pandas as pd
import binary_classifier as bc
import training as tr
import predict as pr
import app

def main():

    df = pd.read_csv(r'C:\Users\KaustubhKalyankar\Desktop\Customer Segmentation\Churn_Modelling (1).csv')

    processed_df,target_df = ps.preprocessing(df)
    clustered_df,target_df,df_0,df_1,df_2 = cl.clustering(processed_df,target_df)
    clusters_df = [df_0,df_1,df_2]
    '''
    for clusters in clusters_df:
        cluster_train_data,cluster_test_data,y_train,y_test = bc.split_data(clusters)
        probs_lr,probs_dt,probs_rf,probs_xg,probs_sv,y_test,model_rf = bc.best_classifier(cluster_train_data,cluster_test_data,y_train,y_test)
        probablities_models = [probs_lr,probs_dt,probs_rf,probs_xg,probs_sv]
        names = ["Logistic regression","Decision Tree","Random Forest","XGBoost","SVM"]    
        for p,n  in zip(probablities_models,names):
            bc.plot_calibration_curve(n,1,p,y_test)
    '''

    cluster_train_data,cluster_test_data,y_train,y_test = bc.split_data(clustered_df)
    probs_lr,probs_dt,probs_rf,probs_xg,probs_sv,y_test,model_rf = bc.best_classifier(cluster_train_data,cluster_test_data,y_train,y_test)
    probablities_models = [probs_lr,probs_dt,probs_rf,probs_xg,probs_sv]
    names = ["Logistic regression","Decision Tree","Random Forest","XGBoost","SVM"]

    '''
    for p,n  in zip(probablities_models,names):

            bc.plot_calibration_curve(n,1,p,y_test)
    '''

    bc.plot_calibration_curve("SVM",1,probs_sv,y_test)
    bc.plot_calibration_curve("Logistic regression",2,probs_lr,y_test)
    bc.plot_calibration_curve("Decision Tree",3,probs_dt,y_test)
    bc.plot_calibration_curve("XGBoost",4,probs_xg,y_test)
    bc.plot_calibration_curve("Random Forest",5,probs_rf,y_test)
    filename = "finalized_model.sav"
    pr.predict_rf(filename,cluster_test_data,y_test)
    tr.rf_model(model_rf)


if __name__ == '__main__':
    main()

    