from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
import plotly.graph_objects as go
import numpy as np
import pandas as pd


def clustering(df, target_df):
    
    X = df
    scaler = MinMaxScaler()
    scaler.fit(X)
    X = scaler.transform(X)
    inertia = []
    for i in range(1, 11):
        kmeans = KMeans(
            n_clusters=i, init="k-means++",
            n_init=10,
            tol=1e-04, random_state=42
        )
        kmeans.fit(X)
        inertia.append(kmeans.inertia_)
    fig = go.Figure(data=go.Scatter(x=np.arange(1,11),y=inertia))
    fig.update_layout(title="Inertia vs Cluster Number",xaxis=dict(range=[0,11],title="Cluster Number"),
                    yaxis={'title': 'Inertia'},
                    annotations=[
            dict(
                x=3,
                y=inertia[2],
                xref="x",
                yref="y",
                text="Elbow!",
                showarrow=True,
                arrowhead=7,
                ax=20,
                ay=-40
            )
        ])
    fig.show()

    import plotly.express as px
    kmeans = KMeans(
            n_clusters=3, init="k-means++",
            n_init=10,
            tol=1e-04, random_state=42
        )
    kmeans.fit(X)
    clusters = pd.DataFrame(X, columns=df.columns)
    clusters['label'] = kmeans.labels_
    polar = clusters.groupby("label").mean().reset_index()
    polar = pd.melt(polar, id_vars=["label"])
    fig4 = px.line_polar(polar, r="value", theta="variable", color="label", line_close=True, height=800, width=1400)
    fig4.show()

    target_df['cluster_id'] = kmeans.fit_predict(X)

    df2 = target_df.groupby(['Exited', 'cluster_id'])['Exited'].count()
    print(df2)

    imp = target_df[['Exited', 'cluster_id']]
    df = df.join(imp)

    df_0 = df[df['cluster_id'] == 0]
    df_1 = df[df['cluster_id'] == 1]
    df_2 = df[df['cluster_id'] == 2]

    return df, target_df, df_0, df_1, df_2

    