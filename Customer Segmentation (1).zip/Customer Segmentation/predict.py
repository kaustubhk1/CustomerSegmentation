import pickle
import training as tr
import scikitplot as skplt
import matplotlib.pyplot as plt

def predict_rf(filename,X_test_scaled,y_test):
    # load the model from disk
    loaded_model = pickle.load(open(filename, 'rb'))
    result = loaded_model.score(X_test_scaled, y_test)
    print("Accuracy:", result)
    # Deriving Class probabilities
    predicted_probabilities = loaded_model.predict_proba(X_test_scaled)
    # Creating the plot for random forest
    skplt.metrics.plot_cumulative_gain(y_test, predicted_probabilities,title = "Cumulative gain curve for Random forest")
    plt.show()
    # Creating the plot for random forest
    skplt.metrics.plot_lift_curve(y_test, predicted_probabilities,title = "Lift curve for Random forest")

    # print(predicted_probabilities)
    plt.show()
    return result, filename
    