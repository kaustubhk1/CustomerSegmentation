# import pandas as pd
# import streamlit as st
# import predict as pr

#Title
#st.title("Customer Segmentation and churn Prediction")
#uploaded_file = st.file_uploader("Choose a file to upload")

#Input bar
#a = st.number_input("Enter")

#Dropdown
#b = st.selectbox("select",("x","y"))

import streamlit as st
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans

st.title("Customer Segmentation Based on Customer Behavior")

# Load customer data into a Pandas dataframe
df = pd.read_csv(r'C:\Users\KaustubhKalyankar\Desktop\Customer Segmentation\Churn_Modelling (1).csv')

# Select relevant customer behavior variables
data = df[["CreditScore", "Age", "Tenure","NumOfProducts"]].values

# User Input: Number of Clusters
num_clusters = st.sidebar.slider("Number of Clusters", 2, 5, 3)

# Perform K-Means Clustering
kmeans = KMeans(n_clusters=num_clusters, random_state=0).fit(data)

# Assign cluster labels to each customer
df["cluster"] = kmeans.labels_

# Analyze the characteristics of each cluster
cluster_summary = df.groupby("cluster").mean()

# Display the Cluster Summary
st.write("Cluster Summary")
st.write(cluster_summary)

# Display the Customer Data with Cluster Labels
st.write("Customer Data with Cluster Labels")
st.write(df)
