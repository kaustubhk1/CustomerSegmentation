#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


df = pd.read_csv('/Users/kaustubh/Downloads/customer_seg/Churn_Modelling.csv')
#import csv


# In[3]:


df.head()


# In[4]:


df.duplicated().sum() #remove duplicates if present


# In[5]:


target_df = df[['Exited']].copy()


# In[6]:


df.drop(columns = ['RowNumber','CustomerId','Surname','Exited'],inplace=True)
#unwanted coulmns


# In[7]:


df = pd.get_dummies(df,columns=['Geography','Gender'],drop_first=True)
#one hot encoding


# In[8]:


from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
import plotly.graph_objects as go
import numpy as np
X=df
scaler = MinMaxScaler()
scaler.fit(X)
X=scaler.transform(X)
inertia = []
for i in range(1,11):
    kmeans = KMeans(
        n_clusters=i, init="k-means++",
        n_init=10,
        tol=1e-04, random_state=42
    )
    kmeans.fit(X)
    inertia.append(kmeans.inertia_)
fig = go.Figure(data=go.Scatter(x=np.arange(1,11),y=inertia))
fig.update_layout(title="Inertia vs Cluster Number",xaxis=dict(range=[0,11],title="Cluster Number"),
                  yaxis={'title':'Inertia'},
                 annotations=[
        dict(
            x=3,
            y=inertia[2],
            xref="x",
            yref="y",
            text="Elbow!",
            showarrow=True,
            arrowhead=7,
            ax=20,
            ay=-40
        )
    ])


# In[9]:


import plotly.express as px
kmeans = KMeans(
        n_clusters=3, init="k-means++",
        n_init=10,
        tol=1e-04, random_state=42
    )
kmeans.fit(X)
clusters=pd.DataFrame(X,columns=df.columns)
clusters['label']=kmeans.labels_
polar=clusters.groupby("label").mean().reset_index()
polar=pd.melt(polar,id_vars=["label"])
fig4 = px.line_polar(polar, r="value", theta="variable", color="label", line_close=True,height=800,width=1400)
fig4.show()


# In[10]:


target_df['cluster_id'] = kmeans.fit_predict(X)


# In[11]:


df2 = target_df.groupby(['Exited','cluster_id'])['Exited'].count()


# In[12]:


print(df2)


# In[13]:


imp = target_df[['Exited','cluster_id']]
df = df.join(imp)


# In[14]:


df_0 = df[df['cluster_id'] == 0]
df_1 = df[df['cluster_id'] == 1]
df_2 = df[df['cluster_id'] == 2]


# In[15]:


X = df.drop(columns=['Exited'])
y = df['Exited']
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=0)
#from sklearn.preprocessing import StandardScaler
#scaler = StandardScaler()
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)


# In[16]:


from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC

model_lr = LogisticRegression().fit(X_train_scaled, y_train)
probs_lr = model_lr.predict_proba(X_test_scaled)[:, 1]

model_dt = DecisionTreeClassifier().fit(X_train_scaled, y_train)
probs_dt = model_dt.predict_proba(X_test_scaled)[:, 1]

model_rf = RandomForestClassifier().fit(X_train_scaled, y_train)
probs_rf = model_rf.predict_proba(X_test_scaled)[:, 1]

model_xg = XGBClassifier().fit(X_train_scaled, y_train)
probs_xg = model_xg.predict_proba(X_test_scaled)[:, 1]

model_sv = SVC(probability=True).fit(X_train_scaled, y_train)
probs_sv = model_sv.predict_proba(X_test_scaled)[:, 1]


# In[17]:


import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, roc_curve


auc_lr = roc_auc_score(y_test, probs_lr)
fpr_lr, tpr_lr, thresholds_lr = roc_curve(y_test, probs_lr)

auc_dt = roc_auc_score(y_test, probs_dt)
fpr_dt, tpr_dt, thresholds_dt = roc_curve(y_test, probs_dt)

auc_rf = roc_auc_score(y_test, probs_rf)
fpr_rf, tpr_rf, thresholds_rf = roc_curve(y_test, probs_rf)

auc_xg = roc_auc_score(y_test, probs_xg)
fpr_xg, tpr_xg, thresholds_xg = roc_curve(y_test, probs_xg)

auc_sv = roc_auc_score(y_test, probs_sv)
fpr_sv, tpr_sv, thresholds_sv = roc_curve(y_test, probs_sv)

plt.figure(figsize=(12, 7))
plt.plot(fpr_lr, tpr_lr, label=f'AUC (Logistic Regression) = {auc_lr:.2f}')
plt.plot(fpr_dt, tpr_dt, label=f'AUC (Decision Tree) = {auc_dt:.2f}')
plt.plot(fpr_rf, tpr_rf, label=f'AUC (Random Forests) = {auc_rf:.2f}')
plt.plot(fpr_xg, tpr_xg, label=f'AUC (XGBoost) = {auc_xg:.2f}')
plt.plot(fpr_sv, tpr_sv, label=f'AUC (SVM) = {auc_sv:.2f}')
plt.plot([0, 1], [0, 1], color='blue', linestyle='--', label='Baseline')
plt.title('ROC Curve', size=20)
plt.xlabel('False Positive Rate', size=14)
plt.ylabel('True Positive Rate', size=14)
plt.legend();


# In[18]:


from sklearn.calibration import calibration_curve


def plot_calibration_curve(name, fig_index, probs):
    """Plot calibration curve for est w/o and with calibration. """

    fig = plt.figure(fig_index, figsize=(10, 10))
    ax1 = plt.subplot2grid((3, 1), (0, 0), rowspan=2)
    ax2 = plt.subplot2grid((3, 1), (2, 0))
    
    ax1.plot([0, 1], [0, 1], "k:", label="Perfectly calibrated")
    
    frac_of_pos, mean_pred_value = calibration_curve(y_test, probs, n_bins=10)

    ax1.plot(mean_pred_value, frac_of_pos, "s-", label=f'{name}')
    ax1.set_ylabel("Fraction of positives")
    ax1.set_ylim([-0.05, 1.05])
    ax1.legend(loc="lower right")
    ax1.set_title(f'Calibration plot ({name})')
    
    ax2.hist(probs, range=(0, 1), bins=10, label=name, histtype="step", lw=2)
    ax2.set_xlabel("Mean predicted value")
    ax2.set_ylabel("Count")


# In[19]:


plot_calibration_curve("Logistic regression", 1, probs_lr)


# In[20]:


plot_calibration_curve("Decision Tree", 1, probs_dt)


# In[21]:


plot_calibration_curve("Random Forest", 1, probs_rf)


# In[22]:


plot_calibration_curve("XGBoost", 1, probs_xg)


# In[23]:


plot_calibration_curve("SVM", 1, probs_sv)


# In[24]:


import scikitplot as skplt
# Deriving Class probabilities
predicted_probabilities = model_rf.predict_proba(X_test_scaled)
# Creating the plot for random forest
skplt.metrics.plot_cumulative_gain(y_test, predicted_probabilities)


# In[25]:


# Creating the plot for random forest
skplt.metrics.plot_lift_curve(y_test, predicted_probabilities)


# In[31]:


predicted_probabilities


# In[ ]:




