import binary_classifier as bc
import pickle

def rf_model(model_rf):

    # save the model to disk
    filename = 'finalized_model.sav'
    pickle.dump(model_rf, open(filename, 'wb'))


