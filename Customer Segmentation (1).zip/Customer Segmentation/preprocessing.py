from sklearn import preprocessing
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans

def preprocessing(df):
    df.duplicated().sum() #search duplicates if present

    target_df = df[['Exited']].copy()

    df.drop(columns = ['RowNumber','CustomerId','Surname','Exited'],inplace=True)

    df = pd.get_dummies(df,columns=['Geography','Gender'],drop_first=True) #one hot encoding
    return df,target_df

def differentDataframe(X,target_df,kmeans,df):
    target_df['cluster_id'] = kmeans.fit_predict(X)
    df2 = target_df.groupby(['Exited','cluster_id'])['Exited'].count()
    imp = target_df[['Exited','cluster_id']]
    df = df.join(imp)

    df_0 = df[df['cluster_id'] == 0]
    df_1 = df[df['cluster_id'] == 1]
    df_2 = df[df['cluster_id'] == 2]




