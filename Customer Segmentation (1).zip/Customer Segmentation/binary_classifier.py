from sklearn.calibration import calibration_curve
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC       

import pickle

def split_data(df):
    X = df.drop(columns=['Exited'])
    y = df['Exited']
            
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
    #from sklearn.preprocessing import StandardScaler
    #scaler = StandardScaler()
        
    scaler = MinMaxScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled,X_test_scaled,y_train,y_test


def best_classifier(X_train_scaled, X_test_scaled, y_train,y_test):

    model_lr = LogisticRegression().fit(X_train_scaled, y_train)
    probs_lr = model_lr.predict_proba(X_test_scaled)[:, 1]

    model_dt = DecisionTreeClassifier().fit(X_train_scaled, y_train)
    probs_dt = model_dt.predict_proba(X_test_scaled)[:, 1]

    model_rf = RandomForestClassifier().fit(X_train_scaled, y_train)
    probs_rf = model_rf.predict_proba(X_test_scaled)[:, 1]

    model_xg = XGBClassifier().fit(X_train_scaled, y_train)
    probs_xg = model_xg.predict_proba(X_test_scaled)[:, 1]

    model_sv = SVC(probability=True).fit(X_train_scaled, y_train)
    probs_sv = model_sv.predict_proba(X_test_scaled)[:, 1]

    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_auc_score, roc_curve

    auc_lr = roc_auc_score(y_test, probs_lr)
    fpr_lr, tpr_lr, thresholds_lr = roc_curve(y_test, probs_lr)

    auc_dt = roc_auc_score(y_test, probs_dt)
    fpr_dt, tpr_dt, thresholds_dt = roc_curve(y_test, probs_dt)

    auc_rf = roc_auc_score(y_test, probs_rf)
    fpr_rf, tpr_rf, thresholds_rf = roc_curve(y_test, probs_rf)

    auc_xg = roc_auc_score(y_test, probs_xg)
    fpr_xg, tpr_xg, thresholds_xg = roc_curve(y_test, probs_xg)

    auc_sv = roc_auc_score(y_test, probs_sv)
    fpr_sv, tpr_sv, thresholds_sv = roc_curve(y_test, probs_sv)

    plt.figure(figsize=(12, 7))
    plt.plot(fpr_lr, tpr_lr, label=f'AUC (Logistic Regression) = {auc_lr:.2f}')
    plt.plot(fpr_dt, tpr_dt, label=f'AUC (Decision Tree) = {auc_dt:.2f}')
    plt.plot(fpr_rf, tpr_rf, label=f'AUC (Random Forests) = {auc_rf:.2f}')
    plt.plot(fpr_xg, tpr_xg, label=f'AUC (XGBoost) = {auc_xg:.2f}')
    plt.plot(fpr_sv, tpr_sv, label=f'AUC (SVM) = {auc_sv:.2f}')
    plt.plot([0, 1], [0, 1], color='blue', linestyle='--', label='Baseline')
    plt.title('ROC Curve', size=20)
    plt.xlabel('False Positive Rate', size=14)
    plt.ylabel('True Positive Rate', size=14)
    plt.legend()
    plt.show()

    return probs_lr, probs_dt, probs_rf, probs_xg, probs_sv, y_test, model_rf


def plot_calibration_curve(name, fig_index, probs,y_test):
    """Plot calibration curve. """

    fig = plt.figure(fig_index, figsize=(10, 10))
    ax1 = plt.subplot2grid((3, 1), (0, 0), rowspan=2)
    ax2 = plt.subplot2grid((3, 1), (2, 0))
    
    ax1.plot([0, 1], [0, 1], "k:", label="Perfectly calibrated")
    
    frac_of_pos, mean_pred_value = calibration_curve(y_test, probs, n_bins=10)

    ax1.plot(mean_pred_value, frac_of_pos, "s-", label=f'{name}')
    ax1.set_ylabel("Fraction of positives")
    ax1.set_ylim([-0.05, 1.05])
    ax1.legend(loc="lower right")
    ax1.set_title(f'Calibration plot ({name})')
    
    ax2.hist(probs, range=(0, 1), bins=10, label=name, histtype="step", lw=2)
    ax2.set_xlabel("Mean predicted value")
    ax2.set_ylabel("Count")
    plt.show(block = True)
   


